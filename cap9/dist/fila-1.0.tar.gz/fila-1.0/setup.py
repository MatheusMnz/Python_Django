from setuptools import setup

setup(
    name = 'fila',
    version = '1.0',
    description = 'Gerenciamento de filas',
    author = 'Testes de módulo',
    author_email = 'matheus@gmail.com',
    url = 'teste.com.br',
    py_modules = ['fila'],
)
